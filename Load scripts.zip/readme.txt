1. Publish the database
2. run the scripts for the Class and Status tables first, then the script for the Character table